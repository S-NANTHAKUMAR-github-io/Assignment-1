name = "Datacamp"
type_of_company = "Educational"
print(f"{name} is an {type_of_company} company.")